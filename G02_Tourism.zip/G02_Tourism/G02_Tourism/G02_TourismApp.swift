//
//  G02_TourismApp.swift
//  G02_Tourism
//
//  Created by Golnaz Chehrazi - Zahra Shahin on 2023-06-02.
//

import SwiftUI

@main
struct G02_TourismApp: App {
    
    
    var body: some Scene {
        WindowGroup {
                Login()

        }
    }
}
